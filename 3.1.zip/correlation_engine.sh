#!/bin/bash

# Конфигурация
LOG_DIR="/var/log/security"
CORRELATION_DB="/var/lib/security/correlation.db"
ALERT_THRESHOLD=5
TIME_WINDOW=300  # 5 минут в секундах

# Инициализация БД
init_database() {
    sqlite3 "$CORRELATION_DB" "CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY,
        timestamp INTEGER,
        source_ip TEXT,
        event_type TEXT,
        severity INTEGER,
        details TEXT
    );"
    
    sqlite3 "$CORRELATION_DB" "CREATE TABLE IF NOT EXISTS correlations (
        id INTEGER PRIMARY KEY,
        rule_name TEXT,
        event_count INTEGER,
        first_seen INTEGER,
        last_seen INTEGER,
        source_ips TEXT,
        event_types TEXT,
        severity INTEGER
    );"
}

# Парсинг временной метки
parse_timestamp() {
    date -d "$1" +%s 2>/dev/null || date +%s
}

# Анализ аутентификации
analyze_auth_logs() {
    local current_time=$(date +%s)
    local time_threshold=$((current_time - TIME_WINDOW))
    
    # Обнаружение brute-force атак
    sqlite3 "$CORRELATION_DB" "DELETE FROM events WHERE timestamp < $time_threshold;"
    
    # Анализ неудачных попыток входа
    while read -r line; do
        if echo "$line" | grep -q "Failed password"; then
            timestamp=$(echo "$line" | jq -r '.timestamp')
            src_ip=$(echo "$line" | jq -r '.message' | grep -oE 'from [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | cut -d' ' -f2)
            user=$(echo "$line" | jq -r '.message' | grep -oE 'for [^ ]+' | cut -d' ' -f2)
            
            if [ -n "$src_ip" ] && [ -n "$user" ]; then
                ts_epoch=$(parse_timestamp "$timestamp")
                sqlite3 "$CORRELATION_DB" "INSERT INTO events (timestamp, source_ip, event_type, severity, details) 
                                        VALUES ($ts_epoch, '$src_ip', 'failed_auth', 2, 'User: $user');"
            fi
        fi
    done < <(jq -c '. | select(.syslogtag | contains("sshd"))' "$LOG_DIR/auth.log" 2>/dev/null)
}

# Обнаружение coordinated attacks
detect_coordinated_attacks() {
    local result=$(sqlite3 "$CORRELATION_DB" "SELECT source_ip, COUNT(*) as attempts 
                                            FROM events 
                                            WHERE event_type = 'failed_auth' 
                                            AND timestamp > (strftime('%s','now') - $TIME_WINDOW)
                                            GROUP BY source_ip 
                                            HAVING attempts >= $ALERT_THRESHOLD;")
    
    if [ -n "$result" ]; then
        echo "$(date): COORDINATED BRUTE-FORCE ATTACK DETECTED" >> "$LOG_DIR/correlation_alerts.log"
        echo "$result" >> "$LOG_DIR/correlation_alerts.log"
        
        # Блокировка IP через iptables
        echo "$result" | while IFS='|' read ip attempts; do
            if ! iptables -L INPUT | grep -q "$ip"; then
                iptables -A INPUT -s "$ip" -j DROP
                echo "$(date): Blocked IP $ip ($attempts failed attempts)" >> "$LOG_DIR/blocked_ips.log"
            fi
        done
    fi
}

# Обнаружение lateral movement
detect_lateral_movement() {
    # Поиск подключений между внутренними хостами
    while read -r line; do
        if echo "$line" | grep -q "Accepted password"; then
            src_ip=$(echo "$line" | jq -r '.message' | grep -oE 'from [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | cut -d' ' -f2)
            user=$(echo "$line" | jq -r '.message' | grep -oE 'for [^ ]+' | cut -d' ' -f2)
            
            # Проверяем, является ли IP внутренним
            if [[ $src_ip =~ ^10\. ]] || [[ $src_ip =~ ^192\.168\. ]] || [[ $src_ip =~ ^172\. ]]; then
                echo "$(date): LATERAL MOVEMENT - User $user from internal IP $src_ip" >> "$LOG_DIR/correlation_alerts.log"
            fi
        fi
    done < <(jq -c '. | select(.syslogtag | contains("sshd"))' "$LOG_DIR/auth.log" 2>/dev/null)
}

# Обнаружение privilege escalation
detect_privilege_escalation() {
    # Анализ использования sudo и su
    while read -r line; do
        if echo "$line" | grep -q "sudo\|su"; then
            user=$(echo "$line" | jq -r '.message' | grep -oE '^[^:]+' | head -1)
            command=$(echo "$line" | jq -r '.message' | grep -oE 'COMMAND=.*' | cut -d'=' -f2)
            
            if [ -n "$command" ]; then
                # Проверяем подозрительные команды
                if echo "$command" | grep -qE "(passwd|visudo|useradd|usermod|chmod.*[0-7][0-7][0-7].*/bin|chown.*root)"; then
                    echo "$(date): PRIVILEGE ESCALATION ATTEMPT - User $user executed: $command" >> "$LOG_DIR/correlation_alerts.log"
                fi
            fi
        fi
    done < <(jq -c '.' "$LOG_DIR/apps.log" 2>/dev/null)
}

# Time-based correlation (атаки в нерабочее время)
detect_after_hours_activity() {
    local current_hour=$(date +%H)
    
    # Рабочее время: 9:00 - 18:00
    if [ "$current_hour" -lt 9 ] || [ "$current_hour" -gt 18 ]; then
        # Анализ активности в нерабочее время
        while read -r line; do
            if echo "$line" | grep -q "Accepted password"; then
                user=$(echo "$line" | jq -r '.message' | grep -oE 'for [^ ]+' | cut -d' ' -f2)
                src_ip=$(echo "$line" | jq -r '.message' | grep -oE 'from [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | cut -d' ' -f2)
                
                echo "$(date): AFTER-HOURS ACCESS - User $user from $src_ip" >> "$LOG_DIR/correlation_alerts.log"
            fi
        done < <(jq -c '. | select(.syslogtag | contains("sshd"))' "$LOG_DIR/auth.log" 2>/dev/null)
    fi
}

# Анализ веб-атак
analyze_web_attacks() {
    local current_time=$(date +%s)
    local time_threshold=$((current_time - TIME_WINDOW))
    
    while read -r line; do
        status=$(echo "$line" | jq -r '.status')
        url=$(echo "$line" | jq -r '.url')
        src_ip=$(echo "$line" | jq -r '.src_ip')
        
        # Обнаружение сканирования уязвимостей
        if [[ "$url" =~ (\.php|\.asp|\.cgi|wp-admin|\.\./) ]] && [ "$status" -eq 404 ]; then
            ts_epoch=$(parse_timestamp "$(echo "$line" | jq -r '.timestamp')")
            sqlite3 "$CORRELATION_DB" "INSERT INTO events (timestamp, source_ip, event_type, severity, details) 
                                    VALUES ($ts_epoch, '$src_ip', 'web_scan', 3, 'URL: $url, Status: $status');"
        fi
        
        # Обнаружение SQL injection попыток
        if [[ "$url" =~ (union|select|insert|drop|1=1) ]]; then
            echo "$(date): SQL INJECTION ATTEMPT - IP $src_ip - URL: $url" >> "$LOG_DIR/correlation_alerts.log"
        fi
    done < <(jq -c '.' "$LOG_DIR/webserver.log" 2>/dev/null)
}

# Основной цикл корреляции
main_correlation_loop() {
    init_database
    
    while true; do
        echo "$(date): Running correlation analysis..." >> "$LOG_DIR/correlation.log"
        
        analyze_auth_logs
        analyze_web_attacks
        detect_coordinated_attacks
        detect_lateral_movement
        detect_privilege_escalation
        detect_after_hours_activity
        
        sleep 60
    done
}

# Запуск системы
main_correlation_loop
