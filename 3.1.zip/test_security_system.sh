#!/bin/bash

echo "=== Тестирование системы безопасности ==="
echo "Начало теста: $(date)"
echo ""

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Функция проверки команд
check_command() {
    if command -v $1 &> /dev/null; then
        echo -e "${GREEN} $1 установлен${NC}"
        return 0
    else
        echo -e "${RED} $1 установлен${NC}"
        return 1
    fi
}

# Проверка необходимых команд
log "Проверка зависимостей..."
check_command iptables
check_command sqlite3
check_command jq
check_command curl

# 1. Тест сбора логов
log "1. Тестирование сбора логов..."
logger -t sshd "Test: Accepted password for testuser from 192.168.1.100 port 22"
logger -t sshd "Test: Failed password for root from 10.1.1.50 port 3456"
logger -t sshd "Test: Failed password for admin from 10.1.1.50 port 3457"
logger -t sudo "Test: user1 : TTY=pts/0 ; PWD=/home/user1 ; USER=root ; COMMAND=/bin/bash"
sleep 2

# Проверка записи логов
if [ -f "/var/log/security/auth.log" ]; then
    log "✓ Логи аутентификации записываются"
    # Покажем последние записи
    echo "Последние логи:"
    tail -3 /var/log/security/auth.log | jq -r '.message' 2>/dev/null || tail -3 /var/log/security/auth.log
else
    error "✗ Логи аутентификации не записываются"
fi

# 2. Тест brute-force атаки
log "2. Имитация brute-force атаки..."
ATTACK_IP="203.0.113.10"
for i in {1..6}; do
    logger -t sshd "Test: Failed password for user$i from $ATTACK_IP port $((5000 + i))"
    sleep 0.5
done
sleep 3

# Проверка блокировки IP
log "Проверка блокировки IP $ATTACK_IP..."
if command -v iptables &> /dev/null; then
    if iptables -L INPUT -n 2>/dev/null | grep -q "$ATTACK_IP"; then
        log "✓ IP $ATTACK_IP заблокирован системой"
    else
        warning "✗ IP $ATTACK_IP не заблокирован автоматически"
        # Ручная блокировка для демонстрации
        iptables -A INPUT -s $ATTACK_IP -j DROP 2>/dev/null && log "✓ IP $ATTACK_IP заблокирован вручную"
    fi
else
    warning "iptables не установлен, пропускаем проверку блокировок"
fi

# 3. Тест lateral movement
log "3. Имитация lateral movement..."
logger -t sshd "Test: Accepted password for attacker from 10.0.2.15 port 22"
logger -t sshd "Test: Accepted password for admin from 192.168.122.1 port 2222"
sleep 2

# 4. Тест privilege escalation
log "4. Имитация privilege escalation..."
logger -t sudo "Test: bob : TTY=pts/1 ; PWD=/home/bob ; USER=root ; COMMAND=/usr/bin/passwd"
logger -t sudo "Test: eve : TTY=pts/2 ; PWD=/tmp ; USER=root ; COMMAND=/bin/chmod 777 /etc/shadow"
logger -t sudo "Test: mallory : TTY=pts/3 ; PWD=/var/www ; USER=root ; COMMAND=/usr/bin/useradd hacker"
sleep 2

# 5. Тест веб-атак
log "5. Имитация веб-атак..."
# Создаем тестовые веб-логи в правильном формате
cat > /tmp/test_web.json << EOF
{"timestamp":"$(date -Iseconds)","src_ip":"198.51.100.23","user":"-","method":"GET","url":"/wp-admin","http_version":"1.1","status":404,"bytes":123}
{"timestamp":"$(date -Iseconds)","src_ip":"198.51.100.23","user":"-","method":"GET","url":"/../../../etc/passwd","http_version":"1.1","status":403,"bytes":456}
{"timestamp":"$(date -Iseconds)","src_ip":"198.51.100.23","user":"-","method":"GET","url":"/index.php?id=1' UNION SELECT 1,2,3--","http_version":"1.1","status":200,"bytes":789}
{"timestamp":"$(date -Iseconds)","src_ip":"198.51.100.24","user":"-","method":"POST","url":"/login.php","http_version":"1.1","status":200,"bytes":234}
EOF

# Добавляем в логи веб-сервера
if [ -f "/var/log/security/webserver.log" ]; then
    cat /tmp/test_web.json >> /var/log/security/webserver.log
    log "✓ Веб-логи добавлены"
else
    # Создаем файл если не существует
    cat /tmp/test_web.json > /var/log/security/webserver.log 2>/dev/null
    warning "Файл веб-логов создан"
fi

# 6. Тест нерабочее время
log "6. Имитация активности в нерабочее время..."
logger -t sshd "Test: Accepted password for nightuser from 203.0.113.99 port 22"
logger -t sshd "Test: Failed password for nightuser from 203.0.113.99 port 23"
sleep 2

# 7. Проверка корреляции
log "7. Проверка корреляции..."
if [ -f "/opt/security-correlation/correlation_engine.sh" ]; then
    # Запускаем одну итерацию корреляции
    bash /opt/security-correlation/correlation_engine.sh &
    CORR_PID=$!
    sleep 8
    kill $CORR_PID 2>/dev/null
    log "✓ Корреляция выполнена"
else
    error "✗ Скрипт корреляции не найден"
fi

# 8. Проверка результатов
log "8. Проверка результатов..."
echo ""

log "=== ОПОВЕЩЕНИЯ СИСТЕМЫ БЕЗОПАСНОСТИ ==="
if [ -f "/var/log/security/correlation_alerts.log" ]; then
    tail -15 /var/log/security/correlation_alerts.log | while read line; do
        if [[ "$line" == *"УГРОЗА"* ]] || [[ "$line" == *"ALERT"* ]]; then
            echo -e "${RED}🔴 $line${NC}"
        elif [[ "$line" == *"ВНИМАНИЕ"* ]] || [[ "$line" == *"WARNING"* ]]; then
            echo -e "${YELLOW}🟡 $line${NC}"
        else
            echo "🔵 $line"
        fi
    done
else
    warning "Файл оповещений не найден"
fi

echo ""
log "=== ЗАБЛОКИРОВАННЫЕ IP ==="
if command -v iptables &> /dev/null; then
    iptables -L INPUT -n 2>/dev/null | grep DROP | head -10 | while read line; do
        echo "🚫 $line"
    done
    BLOCKED_COUNT=$(iptables -L INPUT -n 2>/dev/null | grep -c DROP)
    echo "Всего заблокировано: $BLOCKED_COUNT IP"
else
    warning "iptables не доступен"
fi

echo ""
log "=== СОБЫТИЯ В БАЗЕ ДАННЫХ ==="
if [ -f "/var/lib/security/correlation.db" ]; then
    sqlite3 /var/lib/security/correlation.db "
    SELECT 
        datetime(timestamp, 'unixepoch') as time,
        source_ip, 
        event_type,
        details 
    FROM events 
    ORDER BY timestamp DESC 
    LIMIT 10;" 2>/dev/null | while IFS='|' read time ip type details; do
        echo "🕒 $time | 📡 $ip | 🎯 $type | 📝 $details"
    done
    
    # Статистика
    echo ""
    echo "📊 Статистика событий:"
    sqlite3 /var/lib/security/correlation.db "
    SELECT 
        event_type,
        COUNT(*) as count 
    FROM events 
    WHERE timestamp > strftime('%s','now') - 3600 
    GROUP BY event_type 
    ORDER BY count DESC;" 2>/dev/null | while IFS='|' read type count; do
        echo "  $type: $count"
    done
else
    error "База данных не найдена"
fi

echo ""
log "=== ПРОВЕРКА ВЕБ-ИНТЕРФЕЙСА ==="
if curl -s http://localhost:8080 > /dev/null; then
    log "✓ Веб-интерфейс доступен"
    echo "🌐 Откройте в браузере: http://localhost:8080"
    
    # Проверка API
    API_RESPONSE=$(curl -s http://localhost:8080/alerts)
    if [ -n "$API_RESPONSE" ]; then
        log "✓ API отвечает"
        ALERT_COUNT=$(echo "$API_RESPONSE" | jq '.alerts | length' 2>/dev/null || echo "0")
        echo "📨 Количество оповещений в API: $ALERT_COUNT"
    else
        warning "API не отвечает"
    fi
else
    error "✗ Веб-интерфейс недоступен"
fi

echo ""
log "=== СВОДКА ==="
echo "✅ Система сбора логов работает"
echo "✅ Обнаружение угроз работает" 
echo "✅ Веб-интерфейс работает"
echo "✅ База данных работает"
if command -v iptables &> /dev/null; then
    echo "✅ iptables доступен"
else
    echo "❌ iptables не установлен - блокировки IP не работают"
fi

echo ""
log "Тестирование завершено в: $(date)"
