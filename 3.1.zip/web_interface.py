#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import sqlite3
import datetime

DB_PATH = "/var/lib/security/correlation.db"

class SecurityHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            html = """
            <html>
            <head>
                <title>Security Events Dashboard</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .alert { padding: 10px; margin: 5px; border-radius: 5px; }
                    .high { background-color: #ffcccc; border-left: 5px solid #ff0000; }
                    .medium { background-color: #fff3cd; border-left: 5px solid #ffc107; }
                    .low { background-color: #d4edda; border-left: 5px solid #28a745; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
                </style>
            </head>
            <body>
                <h1>Security Events Dashboard</h1>
                <div id="alerts"></div>
                <script>
                    function loadAlerts() {
                        fetch('/alerts')
                            .then(response => response.json())
                            .then(data => {
                                const alertsDiv = document.getElementById('alerts');
                                alertsDiv.innerHTML = '<h2>Recent Alerts</h2>';
                                
                                const table = document.createElement('table');
                                table.innerHTML = `
                                    <tr>
                                        <th>Time</th>
                                        <th>Source IP</th>
                                        <th>Event Type</th>
                                        <th>Severity</th>
                                        <th>Details</th>
                                    </tr>
                                `;
                                
                                data.alerts.forEach(alert => {
                                    const row = table.insertRow();
                                    row.innerHTML = `
                                        <td>${alert.timestamp}</td>
                                        <td>${alert.source_ip}</td>
                                        <td>${alert.event_type}</td>
                                        <td>${alert.severity}</td>
                                        <td>${alert.details}</td>
                                    `;
                                });
                                
                                alertsDiv.appendChild(table);
                            });
                    }
                    
                    setInterval(loadAlerts, 5000);
                    loadAlerts();
                </script>
            </body>
            </html>
            """
            self.wfile.write(html.encode())
            
        elif self.path == '/alerts':
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT timestamp, source_ip, event_type, severity, details 
                FROM events 
                WHERE timestamp > strftime('%s','now') - 3600 
                ORDER BY timestamp DESC 
                LIMIT 100
            """)
            
            alerts = []
            for row in cursor.fetchall():
                alerts.append({
                    'timestamp': datetime.datetime.fromtimestamp(row[0]).strftime('%Y-%m-%d %H:%M:%S'),
                    'source_ip': row[1],
                    'event_type': row[2],
                    'severity': row[3],
                    'details': row[4]
                })
            
            conn.close()
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'alerts': alerts}).encode())

def run_server():
    server = HTTPServer(('0.0.0.0', 8080), SecurityHandler)
    print('Security dashboard running on http://0.0.0.0:8080')
    server.serve_forever()

if __name__ == '__main__':
    run_server()
